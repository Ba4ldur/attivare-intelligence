# Regime Regular RTC — implantação isolada

O Attivare continua sendo o único site e a API `/api/rtc` continua exigindo usuário
autenticado e perfil ativo. O Java roda **em outro projeto Replit, em VM Reservada
(Reserved VM)**. Não registre o serviço como outro artefato do projeto Attivare:
artefatos desse projeto compartilham a publicação, e não teriam ciclo de vida
independente.

O único listener encaminhado pelo Replit é o da fachada HTTP (`PORT`, padrão
8080). O Spring usa só `127.0.0.1:19931` e o readiness `127.0.0.1:19941`.
`GET /` é apenas liveness, vazio. Consultas, cálculo, grupos XML e readiness
exigem `X-RTC-Service-Token`. A fachada não publica Swagger, métricas, detalhes
do Actuator nem caminhos arbitrários. O Java recebe um ambiente sem os segredos
do serviço e usa a base SQLite V0059 com arquivo 0444 e `mode=ro`.

## Publicação manual, na ordem

1. No projeto Attivare, execute `python3 scripts/rtc/export-regular-service.py`
   para obter `generated-artifacts/rtc-regular-service.zip`. Importe o ZIP em
   **um novo projeto Replit**. Ele contém apenas o código e os scripts do
   serviço, sem segredos, sem dados de usuários e sem dependências do projeto
   principal. O build baixa e verifica a revisão homologada, monta o SQLite e
   empacota o Java 21. Em produção, o comando é `bash run.sh`, depois de
   `bash build.sh`, conforme a `.replit` incluída.
2. No novo projeto, configure `RTC_REGULAR_SERVICE_TOKEN` nos **Secrets de
   produção** com 32 bytes aleatórios em hexadecimal minúsculo (64 caracteres;
   gere no seu gerenciador de senhas/segredos). Publique manualmente como
   **Reserved VM**, mesma região do Attivare quando disponível. Comece com
   **1 vCPU dedicada e 1 GiB RAM**, se disponíveis; não use uma configuração
   abaixo disso sem medir. Use **visibilidade Private** quando o workspace
   permitir tokens externos. Depois da primeira publicação privada, crie um
   **External Access Token de Production** nas configurações de publicação.
   Se esse recurso não estiver disponível, uma publicação pública do serviço
   só deve ser usada se a política do workspace permitir; nesse caso a fachada
   continua negando toda rota funcional sem a chave própria e o Java continua
   inacessível publicamente. Não configure token externo nesse modo.
3. Nos **Secrets de produção** do Attivare, configure
   `RTC_REGULAR_SERVICE_URL` com a origem HTTPS publicada do serviço
   (sem caminho, query ou credenciais), `RTC_REGULAR_SERVICE_TOKEN` com o mesmo
   segredo da etapa 2 e, em modo privado, `RTC_REGULAR_REPLIT_ACCESS_TOKEN`
   com o token externo de produção. Nunca use prefixo `VITE_`, token de usuário,
   chave Supabase ou parâmetro de URL para isso. O token de borda vai em
   `Authorization`; a chave do serviço continua obrigatória mesmo com ele.
4. **Antes de republicar o Attivare**, confirme que o serviço responde à
   prontidão autenticada (`GET /internal/rtc/readiness` = `204`), que uma chamada
   sem credenciais não chega ao Java e que uma consulta sintética de UF
   funciona. Só então publique manualmente a revisão do Attivare. Confirme
   `/api/healthz`, login já existente, `/api/rtc/status` autenticado, consulta,
   cálculo e DANFSe. Não use documentos reais no teste de implantação.

Se o segredo ou URL estiver ausente, o Attivare segue funcionando e o Regime
Regular fica **Indisponível**. A indicação **Inicializando** exige resposta
autenticada da fachada (`503` com `X-RTC-State: starting`), somente nos
primeiros 300 s e antes do primeiro `UP`. Após a janela, uma falha de prontidão
fica **Indisponível**; a janela só muda o status e não mata o Java. Queda de
rede, credenciais inválidas ou perda de prontidão após o primeiro `UP` também
indicam indisponibilidade. Quando a prontidão retorna, o Attivare se recupera
sem reiniciar. A Visão Geral atualiza a cada 4 s durante a inicialização e
a cada 15 s nos demais estados. A sondagem tem timeout de 2,5 s e cache de
3 s; cálculos são enviados uma única vez, sem repetição automática.
A VM fica sempre ativa para evitar cold starts por tráfego. Não há promessa de
alta disponibilidade de uma única instância; a VM tem seu próprio ciclo de
vida, e uma queda afeta apenas as ferramentas dependentes do Regime Regular.

O Simples Nacional permanece **Em homologação**. Uma integração futura poderá
usar esse mesmo padrão de projeto independente, fachada restrita e credenciais
próprias. Este pacote não contém nem inicia o motor do Simples e não expõe
nenhuma rota funcional correspondente.

## Rollback e validação

- **Serviço:** restaure a última revisão funcional da VM, mantendo a mesma
  origem e um par de credenciais válido. O Attivare reconecta sozinho. Não é
  necessário restaurar banco, usuários, Simulador ou dados fiscais.
- **Attivare:** se a própria revisão apresentar uma regressão, aponte-a para a
  revisão anterior pelo mecanismo de publicação/rollback do Replit. A revisão
  anterior remonta o Java local e pode reintroduzir o problema de startup; não
  é a correção definitiva. Não desligue a VM durante um rollback do Attivare
  até decidir qual revisão ficará ativa.
- **Local:** `pnpm --filter @workspace/api-server build` e
  `bash scripts/rtc/check-package.sh` (requer portas 19931, 19933 e 19941 livres;
  pare somente o workflow gerenciado da API se necessário). Usa auth sintética,
  HTTPS local e dois pacotes em diretórios independentes.
