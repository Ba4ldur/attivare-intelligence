#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python3 scripts/rtc/build.py regular
stage="$(mktemp -d .rtc-build.XXXXXX)"
trap 'rm -rf -- "$stage"' EXIT
python3 scripts/rtc/package-runtime.py regular "$stage"
rm -rf -- dist
mv -- "$stage" dist
