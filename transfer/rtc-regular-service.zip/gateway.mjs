import { timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";

const maxInput = 2 * 1024 * 1024;
const maxOutput = 4 * 1024 * 1024;
const key = process.env.RTC_REGULAR_SERVICE_TOKEN;
const port = Number(process.env.PORT || 8080);
const host = process.env.RTC_BIND_HOST === "127.0.0.1" ? "127.0.0.1" : "0.0.0.0";
if (!key || !/^[0-9a-f]{64}$/.test(key) || !Number.isInteger(port) || port < 1 || port > 65535 ||
    port === 19931 || port === 19941) {
  console.error("RTC regular: invalid service credential or port configuration");
  process.exit(1);
}
const secret = Buffer.from(key, "hex");
const catalog = /^\/api\/calculadora\/dados-abertos\/(?:ncm|nbs|situacoes-tributarias\/cbs-ibs|classificacoes-tributarias\/cbs-ibs(?:\/\d{3}|\/class-trib\/\d{6})?|fundamentacoes-legais|ufs(?:\/municipios)?|versao)$/;
const calc = "/api/calculadora/observabilidade/regime-geral";
const validate = "/api/calculadora/xml/validate";
const generate = "/api/calculadora/xml/generate";
const readiness = "/internal/rtc/readiness";
let active = 0;
let healthPending;
let lastHealth;
let wasReady = false;
const startedAt = performance.now();
const startupStatusWindowMs = 300_000; // Only affects status; never stops Java.

function isReady() {
  if (healthPending) return healthPending;
  healthPending = (async () => {
    let ready = false;
    try {
      const res = await fetch("http://127.0.0.1:19941/health/readiness", {
        redirect: "error", signal: AbortSignal.timeout(1500),
      });
      if (res.ok) ready = (await res.json()).status === "UP";
      else await res.body?.cancel();
    } catch { /* unavailable */ }
    if (lastHealth !== ready) console.info(`RTC regular: ${ready ? "ready" : "not ready"}`);
    lastHealth = ready;
    wasReady ||= ready;
    return ready;
  })().finally(() => { healthPending = undefined; });
  return healthPending;
}

async function handle(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (req.method === "GET" && req.url === "/") { res.writeHead(200).end(); return; } // platform liveness only
  const token = req.headers["x-rtc-service-token"];
  if (typeof token !== "string" || !/^[0-9a-f]{64}$/.test(token) ||
      !timingSafeEqual(Buffer.from(token, "hex"), secret)) {
    res.writeHead(401, { Connection: "close" }).end(); return;
  }
  if (req.method === "GET" && req.url === readiness) {
    if (await isReady()) { res.writeHead(204).end(); return; }
    if (!wasReady && performance.now() - startedAt < startupStatusWindowMs) {
      res.setHeader("X-RTC-State", "starting");
    }
    res.writeHead(503).end(); return;
  }
  const [pathname, query = ""] = (req.url || "").split("?", 2);
  const supported = req.method === "GET" ? catalog.test(pathname) :
    req.method === "POST" && [calc, validate, generate].includes(pathname);
  if (!supported || !/^[A-Za-z0-9=&_%+.-]*$/.test(query) || query.length > 512 ||
      (req.url || "").split("?").length > 2 || (pathname === calc && query)) {
    res.writeHead(404, { Connection: "close" }).end(); return;
  }
  if (active >= 4) { res.writeHead(429, { Connection: "close" }).end(); return; }
  active++;
  const signal = AbortSignal.timeout(12_000);
  const cancel = new AbortController();
  const disconnect = () => cancel.abort();
  res.once("close", disconnect);
  try {
    const encoding = req.headers["content-encoding"];
    if (encoding && encoding !== "identity") { res.writeHead(415, { Connection: "close" }).end(); return; }
    if (Number(req.headers["content-length"]) > maxInput) { res.writeHead(413, { Connection: "close" }).end(); return; }
    let body;
    const type = pathname === validate ? "application/xml" : "application/json";
    if (req.method === "POST") {
      if (req.headers["content-type"]?.split(";")[0].trim() !== type) { res.writeHead(415, { Connection: "close" }).end(); return; }
      const chunks = [];
      let size = 0;
      const expire = () => req.destroy(); // never retain a slot for a stalled upload
      signal.addEventListener("abort", expire, { once: true });
      try {
        for await (const chunk of req.iterator({ destroyOnReturn: false })) {
          size += chunk.length;
          if (size > maxInput) { res.writeHead(413, { Connection: "close" }).end(); return; }
          chunks.push(chunk);
        }
      } finally { signal.removeEventListener("abort", expire); }
      body = Buffer.concat(chunks, size);
      if (pathname === validate) {
        let xml;
        try { xml = new TextDecoder("utf-8", { fatal: true }).decode(body); }
        catch { res.writeHead(400).end(); return; }
        if (/\0|<!\s*(?:DOCTYPE|ENTITY)\b/i.test(xml) ||
            /^\s*<\?xml\b[^?]*\bencoding\s*=\s*["'](?!utf-8["'])/i.test(xml)) {
          res.writeHead(400).end(); return;
        }
      }
    }
    const upstream = await fetch(`http://127.0.0.1:19931${pathname}${query ? `?${query}` : ""}`, {
      method: req.method, redirect: "error", body, headers: { "Content-Type": `${type}; charset=utf-8` },
      signal: AbortSignal.any([signal, cancel.signal]),
    });
    if (!upstream.ok) {
      void upstream.body?.cancel().catch(() => {});
      res.writeHead(upstream.status >= 500 ? 502 : 422).end(); return;
    }
    const chunks = [];
    let size = 0;
    if (upstream.body) {
      const reader = upstream.body.getReader();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > maxOutput) { void reader.cancel().catch(() => {}); res.writeHead(502).end(); return; }
        chunks.push(value);
      }
    }
    const headers = { "Content-Type": upstream.headers.get("content-type") || "application/octet-stream" };
    const warning = upstream.headers.get("x-warning-dados-simulados");
    if (warning && /^[1-6]$/.test(warning)) headers["X-Warning-Dados-Simulados"] = warning;
    res.writeHead(upstream.status, headers).end(Buffer.concat(chunks, size));
  } catch {
    if (!res.destroyed && !res.headersSent) res.writeHead(signal.aborted ? 504 : 503, { Connection: "close" }).end();
  } finally {
    active--;
    res.off("close", disconnect);
  }
}

createServer({ requestTimeout: 15_000, headersTimeout: 8_000, connectionsCheckingInterval: 1_000 },
  (req, res) => void handle(req, res).catch(() => {
    if (!res.headersSent) res.writeHead(500, { Connection: "close" });
    res.end();
  }),
).listen(port, host, () => console.info("RTC regular: service listener started"));
