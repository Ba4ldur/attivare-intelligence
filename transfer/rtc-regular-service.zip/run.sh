#!/usr/bin/env bash
# Entry point of the separate deployment only; Node Attivare never runs this.
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
regular="$root/dist/rtc/calculadora-rtc-regime-regular-main"
java="$root/dist/rtc/java/bin/java"
jar="$regular/target/api-regime-geral.jar"
db="$regular/calculadora/db/calculadora-pro.db"
[[ -x "$java" && -r "$jar" && -r "$db" ]] || { echo "RTC regular: missing runtime files" >&2; exit 1; }
[[ "${RTC_REGULAR_SERVICE_TOKEN:-}" =~ ^[0-9a-f]{64}$ ]] || { echo "RTC regular: missing service credential" >&2; exit 1; }
db_uri="$(node -e 'process.stdout.write(require("node:url").pathToFileURL(process.argv[1]).href)' "$db")"
runtime_home="$(mktemp -d)"
gateway_pid= java_pid=
cleanup() {
  trap - EXIT TERM INT
  [[ -z "$gateway_pid" ]] || kill "$gateway_pid" 2>/dev/null || true
  if [[ -n "$java_pid" ]]; then
    kill "$java_pid" 2>/dev/null || true
    # Bound shutdown even if the JVM does not respond to SIGTERM.
    for _ in {1..20}; do kill -0 "$java_pid" 2>/dev/null || break; sleep .1; done
    kill -KILL "$java_pid" 2>/dev/null || true
  fi
  wait || true
  rm -rf -- "$runtime_home"
}
trap cleanup EXIT
trap 'exit 0' TERM INT
node "$root/gateway.mjs" &
gateway_pid=$!
(
  cd "$regular"
  exec env -i LANG=C.UTF-8 HOME="$runtime_home" OTEL_SDK_DISABLED=true \
    "$java" -Xmx512m -XX:ActiveProcessorCount=2 -XX:TieredStopAtLevel=1 -jar "$jar" \
      --spring.profiles.active=offline --server.address=127.0.0.1 --server.port=19931 \
      --server.servlet.context-path=/api \
      "--spring.datasource.url=jdbc:sqlite:${db_uri}?mode=ro&date_class=TEXT&date_string_format=yyyy-MM-dd" \
      --management.server.address=127.0.0.1 --management.server.port=19941 \
      --management.endpoints.web.base-path=/ --management.endpoints.web.exposure.include=health \
      --management.endpoint.health.probes.enabled=true \
      --springdoc.api-docs.enabled=false --springdoc.swagger-ui.enabled=false \
      --logging.level.root=ERROR --logging.level.org.springframework.boot.web.embedded.tomcat=INFO \
      --spring.main.banner-mode=off --versao.url=http://127.0.0.1:9/versao \
      --server.tomcat.threads.max=4 --server.tomcat.accept-count=4 \
    </dev/null > >(LC_ALL=C awk '
      /Tomcat started on port 19931/ && !oper++ {print "RTC regular: operational port listening"; fflush()}
      /Tomcat started on port 19941/ && !mgmt++ {print "RTC regular: management port listening"; fflush()}
      /APPLICATION FAILED TO START|Application run failed/ && !spring++ {print "RTC regular: Spring startup error"; fflush()}
      /OutOfMemoryError|Cannot allocate memory/ && !mem++ {print "RTC regular: JVM memory error"; fflush()}
      /BindException|Address already in use/ && !bind++ {print "RTC regular: port binding error"; fflush()}
      /SQLITE_CANTOPEN|SQLITE_READONLY|Failed to configure a DataSource/ && !db++ {print "RTC regular: SQLite datasource error"; fflush()}
    ') 2>&1
) &
java_pid=$!
# Platform owns lifecycle/restarts. No inactivity watchdog or JVM start deadline.
set +e
wait -n "$java_pid" "$gateway_pid"
status=$?
set -e
echo "RTC regular: service process exited (code=$status)" >&2
exit 1
