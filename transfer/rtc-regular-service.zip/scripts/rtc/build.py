#!/usr/bin/env python3
"""Build only the homologated engines. Never connects to an application database.

Inputs are immutable upstream commits checked against the *entire* uploaded
source tree, not just the SQL. All downloads and outputs stay outside Git.
"""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "generated-artifacts/rtc"
SOURCES = [
    ("calculadora-rtc-regime-regular", "150cccbe414d4a5edea703e4f7a424af5aa222c7",
     "1e1100dab5cc6e88d35130c262f3c7bb741344e8f5c8a1935a293228a711dba6",
     "0ff6d0f19ec3a450156a7fe5987b3a37b19f721b3021b6c4d04cad8b96c5a9a8"),
    ("calculadora-rtc-gerador-danfse", "8d79e6b2f7fad6375340afcb51c85ed370c64a14",
     "6cedb43ce6588d8057f9150628d8ce2902d518ef4880d0b1e59592d1db92b6b6",
     "38fa79aada7d2daaa397b7305a9ddff5616e73b1f699a9cca373c42159d193d2"),
]


def build(engine):
    OUT.mkdir(parents=True, exist_ok=True)
    proof = OUT / ("build-proof.json" if engine == "all" else f"build-proof-{engine}.json")
    wrapper = (ROOT / "scripts/rtc/danfse-loopback.go").read_bytes() if engine != "regular" else b""
    build_key = hashlib.sha256(Path(__file__).read_bytes() + wrapper).hexdigest()
    regular_products = [
        OUT / "calculadora-rtc-regime-regular-main/target/api-regime-geral.jar",
        OUT / "calculadora-rtc-regime-regular-main/calculadora/db/calculadora-pro.db",
    ]
    products = (regular_products if engine != "danfse" else []) + (
        [OUT / "danfse-loopback"] if engine != "regular" else [])
    if proof.exists():
        previous = json.loads(proof.read_text())
        if isinstance(previous, dict) and previous.get("buildKey") == build_key and all(p.exists() for p in products):
            hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in products]
            if hashes == previous.get("productSha256"):
                print("RTC pinned builds already verified.")
                return
    # Strict allowlist, including during builds; never inherit application secrets.
    env = {"PATH": os.environ["PATH"], "HOME": str(ROOT / ".local/rtc-build-home"),
           "LANG": "C.UTF-8", "GOTOOLCHAIN": "go1.27.4", "CGO_ENABLED": "0"}
    Path(env["HOME"]).mkdir(parents=True, exist_ok=True)
    evidence = []
    sources = SOURCES[:1] if engine == "regular" else SOURCES[1:] if engine == "danfse" else SOURCES
    for name, commit, digest, archive_digest in sources:
        cache = OUT / (name + ".zip")
        if not cache.exists():
            uploaded = list((ROOT / "attached_assets").glob(name + "-main_*.zip"))
            if uploaded:
                data = uploaded[0].read_bytes()
                if hashlib.sha256(data).hexdigest() != archive_digest:
                    raise RuntimeError("Uploaded source digest mismatch: " + name)
            else:
                url = f"https://codeload.github.com/ReceitaFederal/{name}/zip/{commit}"
                with urllib.request.urlopen(url, timeout=120) as response:
                    data = response.read(16 * 1024 * 1024 + 1)
                if len(data) > 16 * 1024 * 1024:
                    raise RuntimeError("Source archive too large")
            cache.write_bytes(data)
        data = cache.read_bytes()
        z = zipfile.ZipFile(io.BytesIO(data))
        h = hashlib.sha256()
        members = []
        for entry in sorted(z.namelist()):
            if entry.endswith("/"):
                continue
            relative = entry.split("/", 1)[1]
            if ".." in Path(relative).parts or Path(relative).is_absolute():
                raise RuntimeError("Unsafe source path")
            content = z.read(entry)
            h.update(relative.encode() + b"\0" + hashlib.sha256(content).digest())
            members.append((relative, content))
        if h.hexdigest() != digest:
            raise RuntimeError("Source tree differs from homologated input: " + name)
        target = OUT / (name + "-main")
        # A rebuild must not compile stale/extra sources or reuse a modified
        # target from an earlier workspace session.
        if target.exists():
            shutil.rmtree(target)
        target.mkdir()
        for relative, content in members:
            path = target / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        evidence.append({"name": name, "commit": commit, "treeSha256": digest,
                         "uploadedArchiveSha256": archive_digest, "files": len(members)})

    def run(args, cwd):
        subprocess.run(args, cwd=cwd, env=env, check=True, timeout=900)
    if engine != "danfse":
        regular = OUT / "calculadora-rtc-regime-regular-main"
        database = regular_products[1]
        database.parent.mkdir(parents=True, exist_ok=True)
        # A new isolated SQLite reference database only.
        if database.exists():
            database.chmod(0o600)
            database.unlink()
        run(["mvn", "-B", "-q", "-DskipTests", "package"], regular)
        run(["mvn", "-B", "-q", "flyway:migrate",
             "-Dflyway.configFiles=flyway/flyway-pro.conf"], regular)
        with sqlite3.connect(f"file:{database}?mode=ro", uri=True) as conn:
            assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            assert not conn.execute("PRAGMA foreign_key_check").fetchall()
            # Includes Flyway and SQLite statistics (54 application tables).
            assert conn.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0] == 57
            assert conn.execute("SELECT max(version) FROM flyway_schema_history").fetchone()[0] == "0059"
        database.chmod(0o444)
    if engine != "regular":
        danfse = OUT / "calculadora-rtc-gerador-danfse-main"
        harness = danfse / "cmd/attivare-loopback/main.go"
        harness.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / "scripts/rtc/danfse-loopback.go", harness)
        run(["go", "build", "-trimpath", "-o", str(OUT / "danfse-loopback"),
             "./cmd/attivare-loopback"], danfse)
    proof.write_text(json.dumps({"buildKey": build_key, "sources": evidence,
        "productSha256": [hashlib.sha256(p.read_bytes()).hexdigest() for p in products]}, indent=2))
    print(f"RTC {engine} built. No Simples engine was extracted or executed.")


if __name__ == "__main__":
    engine = sys.argv[1] if len(sys.argv) == 2 else "all"
    if engine not in {"all", "regular", "danfse"} or len(sys.argv) > 2:
        sys.exit("Expected all, regular or danfse")
    build(engine)
