"""Stage separate, checksum-verified RTC runtimes."""
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / "generated-artifacts" / "rtc"
REGULAR = "calculadora-rtc-regime-regular-main"
PRODUCTS = {"regular": (f"{REGULAR}/target/api-regime-geral.jar",
                       f"{REGULAR}/calculadora/db/calculadora-pro.db"),
            "danfse": ("danfse-loopback",)}
JRE_RELEASE = "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13%2B9/"
JRE_BUILDS = {
    "x86_64": ("x64", "a535a1df9c6284d9618872984e026ae0352d1f7e9e0605425c0e6114f47351dd"),
    "aarch64": ("aarch64", "b1734db7ade49c3f6acc6ae06233b8c2dd90e3e2f00f67000ae1c972aaa64d8c"),
}


def digest(file):
    with file.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def java_archive(arch, expected_jre):
    archive = CACHE / f"OpenJDK21U-jre_{arch}_linux_hotspot_21.0.13_9.tar.gz"
    if not archive.is_file() or digest(archive) != expected_jre:
        with tempfile.NamedTemporaryFile(dir=CACHE) as downloaded:
            with urllib.request.urlopen(JRE_RELEASE + archive.name, timeout=60) as source:
                shutil.copyfileobj(source, downloaded)
            downloaded.flush()
            if digest(Path(downloaded.name)) != expected_jre:
                raise RuntimeError("Pinned RTC Java archive checksum mismatch")
            shutil.copyfile(downloaded.name, archive)
    return archive


def main(engine, dist):
    if platform.system() != "Linux" or platform.machine() not in JRE_BUILDS:
        raise RuntimeError("RTC package requires Linux x86_64 or aarch64")
    arch, expected_jre = JRE_BUILDS[platform.machine()]
    if engine == "danfse":
        with (CACHE / "danfse-loopback").open("rb") as binary:
            header = binary.read(20)
        expected_machine = 62 if arch == "x64" else 183
        if header[:6] != b"\x7fELF\x02\x01" or int.from_bytes(header[18:20], "little") != expected_machine:
            raise RuntimeError("RTC Go binary does not match the production Linux architecture")
    with tempfile.TemporaryDirectory(prefix=".rtc-stage-", dir=dist) as temp:
        stage = Path(temp)
        rtc = stage / "rtc"
        rtc.mkdir()
        if engine == "regular":
            with tarfile.open(java_archive(arch, expected_jre), "r:gz") as package:
                package.extractall(stage, filter="data")
            (stage / "jdk-21.0.13+9-jre").rename(rtc / "java")
        proof = json.loads((CACHE / f"build-proof-{engine}.json").read_text())
        modes = (0o444, 0o444) if engine == "regular" else (0o755,)
        for rel, expected, mode in zip(PRODUCTS[engine], proof["productSha256"], modes, strict=True):
            dest = rtc / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(CACHE / rel, dest)
            dest.chmod(mode)
            if digest(dest) != expected:
                raise RuntimeError(f"Staged RTC checksum mismatch: {rel}")
        if engine == "regular":
            java = rtc / "java" / "bin" / "java"
            result = subprocess.run([str(java), "-version"], capture_output=True, text=True,
                                    env={"LANG": "C.UTF-8"}, check=True, timeout=15)
            if 'version "21.' not in result.stderr:
                raise RuntimeError("Staged RTC Java is not Java 21")
        os.rename(rtc, dist / "rtc")
        print(f"RTC {engine} runtime verified and staged.")


if __name__ == "__main__":
    main(sys.argv[1], Path(sys.argv[2]).resolve())
